Please return the following files to ChatGPT for interpretation and manuscript redesign:

ESSENTIAL
1. Qingshuijiang_FPE_All_Results.xlsx
2. 00_Qingshuijiang_FPE_Coding_Audit.xlsx
3. Table_16_logistic_trends_per_50_years.csv
4. Table_19_layered_tenure_cases.csv
5. Table_20_labour_based_entitlement_cases.csv
6. Table_21_reversion_cases.csv
7. Table_22_audit_sample_without_full_text.csv

FIGURES
8. Figure_03_rights_bundle_network.png
9. Figure_04_resource_right_heatmap.png
10. Figure_05_institutional_profiles_by_period.png
11. Figure_06_rights_bundle_size_by_period.png

REPRODUCIBILITY
12. sessionInfo.txt

Do not revise the manuscript on the basis of the automatic coding alone.
The high-value cases should first be manually audited against the source text/image.
After the codebook is frozen, a second coder should independently code a stratified sample.
