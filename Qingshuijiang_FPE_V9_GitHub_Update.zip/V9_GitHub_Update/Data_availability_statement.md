# Data availability statement

## Public repository version — use after the update is uploaded

The research code and supporting materials are available in the [project repository](https://github.com/JKAECN/qingshuijiang-forest-tenure-reproducibility). The repository contains the structured corpus workbook, the R analysis workflow with its embedded coding dictionary, and an archive of Supplementary Tables S0–S6, period-comparison outputs, and figures. A [clause evidence table](https://github.com/JKAECN/qingshuijiang-forest-tenure-reproducibility/blob/main/v9_evidence/Table_5_clause_evidence.csv) provides source identifiers, page locations, selected excerpts, and working translations for the contracts discussed in Section 5.7 and Table 5. Facsimiles of the published source volumes are not redistributed.

## Anonymised manuscript — use if the repository URL would identify the authors

The R workflow, structured corpus, supporting audit tables, and source locations for the selected clauses can be made available in anonymised form for peer review. Section 5.7 and Table 5 identify the relevant contracts and published pages. Facsimiles of the published source volumes are not redistributed.
