# 上传说明

目标仓库：[https://github.com/JKAECN/qingshuijiang-forest-tenure-reproducibility](https://github.com/JKAECN/qingshuijiang-forest-tenure-reproducibility)

解压后，将 `upload_to_repository/` **里面的文件和文件夹**放到仓库根目录。根目录应能直接看到 `README.md` 和 `v9_evidence/`。

| 要处理的文件 | 操作 |
| --- | --- |
| `README.md` | 放在根目录，作为新的仓库说明；确认新说明正常显示后，可把原 `README (1).md` 移到旧版资料目录或删除。 |
| `v9_evidence/Table_5_clause_evidence.csv` | 新增，保持目录和文件名不变；公开版数据声明链接指向这个路径。 |

原有 R 脚本、语料工作簿、严格分析 ZIP、旧结果 ZIP 和手工释录无需重新上传。两个 ZIP 中只有 `Qingshuijiang_FPE_strict_v2.zip` 对应 V9 保留的148份统计分析。本次没有重跑 R 流程或替换原结果。

上传后打开仓库首页，点击 README 中的 V9 证据表链接，确认文件可访问，再使用 `Data_availability_statement.md` 中的公开版本。若匿名审稿阶段不宜展示含个人账号的仓库地址，使用该文件中的匿名表述。此说明及数据声明供作者使用，无需上传到公开仓库。
